package com.file.lock.screens;

import com.file.lock.items.Directory;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Scanner;


    public class FileOptionsScreen implements Screen {

        private Directory dir = new Directory();
        Scanner sc = new Scanner(System.in);

        private ArrayList<String> menu = new ArrayList<>();

        public FileOptionsScreen() {
            menu.add("1. ADD A NEW FILE");
            menu.add("2. DELETE AN EXISTING FILE");
            menu.add("3. SEARCH FOR A FILE BY IT'S NAME");
            menu.add("4. RETURN TO MAIN_MENU");
        }


        public void Show() {
            System.out.println("\nFILE OPERATIONS FUNCTIONS\n");
            for (String s : menu) {
                System.out.println(s);
            }
        }


        public void GetUserInput() {
            int selectedOption;
            System.out.println("Enter the no. : ");
            selectedOption = sc.nextInt();
            while (selectedOption != 5) {
                this.NavigateOption(selectedOption);
                System.out.println("Enter the no. : ");
                selectedOption = sc.nextInt();
            }
        }


        public void NavigateOption(int option) {
            switch (option) {

                case 1:
                    this.AddFile();
                    this.Show();
                    break;

                case 2:
                    this.DeleteFile();
                    this.Show();
                    break;
                case 3:
                    this.SearchFile();
                    this.Show();
                    break;

                case 4:
                
                break;

                default:
                    System.out.println("SORRY! OPTION NOT AVAILABLE, PLEASE TRY ANOTHER ONE");
                    break;
            }
        }

        public void AddFile() {
            System.out.println("ENTER THE FILE NAME TO BE ADDED :- ");
            String item = this.getInputString();
            try {
                Path path = FileSystems.getDefault().getPath(Directory.name + item).toAbsolutePath();
                File file = new File(dir.getName() + item);

                if (file.createNewFile()) {
                    System.out.println("NEW FILE CREATED AS :- " + file.getName());
                    dir.getFiles().add(file);
                }
                else {
                    System.out.println("AH SWAP! FILE ALREADY EXIST");
                }
                }
            catch (IOException e) {
                System.out.println(e);
            }
        }
        public void DeleteFile() {
            System.out.println("ENTER THE FILE NAME TO BE DELETED :- ");
            String item = this.getInputString();
            Path path = FileSystems.getDefault().getPath(Directory.name + item).toAbsolutePath();
            File file_path = path.toFile();
            if (file_path.delete()) {
                System.out.println("DELETED FILE NAME :- " + file_path.getName());
                dir.getFiles().remove(file_path);
            } else {
                System.out.println("OOPS! OPERATION NOT POSSIBLE. " + item + " DOESN'T EXISTS");
            }
        }

        public void SearchFile() {
            Boolean found = false;
            System.out.println("WHICH FILE DO YOU WANT? PLEASE ENTER ITS NAME HERE :- ");
            String item = this.getInputString();
            System.out.println("YOU LOOKED FOR :- " + item);
            ArrayList<File> all_files = dir.getFiles();
            for (int i = 0; i < all_files.size(); i++) {
                if (all_files.get(i).getName().equals(item)) {
                    System.out.println("HERE's YOUR FILE :- " + item);
                    found = true;
                }
            }
            if (found == false) {
                System.out.println("SORRY! FILE NOT FOUND");
            }
        }

        private String getInputString() {
            Scanner sc = new Scanner(System.in);
            return (sc.nextLine());

        }
    }

