package com.file.lock.screens;
import com.file.lock.services.DirectoryService;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

 public class WelcomeScreen implements Screen {

        private  String pname = "\n-----------------LOCKEDME.COM----------------------";

        private String madeby = "                      -Developed by Manish Chaurasiya";

        private ArrayList<String> menu = new ArrayList<>();

        FileOptionsScreen file = new FileOptionsScreen();
        public WelcomeScreen() {
            menu.add("1.DISPLAY ALL FILES");
            menu.add("2.GET ON TO FILE OPERATIONS MENU");
            menu.add("3.QUIT/EXIT");
            menu.add("---------------------------------------------------");
        }
        public void introWS() {
            System.out.println(pname);
            System.out.println(madeby);
            Show();
        }

        public void Show() {
            System.out.println("---------------------------------------------------");
            System.out.println("WELCOME TO MAIN-MENU !");
            System.out.println("---------------------------------------------------");
            for (String s : menu) {
                System.out.println(s);
            }
        }

        public void GetUserInput() {
            int selectedOption = 0;
            while ((selectedOption = this.getOption()) != 4) {
                this.NavigateOption(selectedOption);
            }
        }

        public void NavigateOption(int option) {
            switch (option) {
                case 1:
                    this.ShowFiles();
                    this.Show();
                    break;

                case 2:
                    file.Show();
                    file.GetUserInput();
                    break;

                case 3:
                {
                    System.out.println("THANK-YOU FOR USING LOCKEDME.COM");
                    break;

                }

                default:
                    System.out.println("OOPS! INVALID OPTION");
                    break;
            }

        }


        public void ShowFiles() {
            System.out.println("HERE ARE YOUR STORED FILES :-  ");
            DirectoryService.PrintFiles();
        }


        private int getOption() {
            Scanner in = new Scanner(System.in);
            int returnOption = 0;
            try
            {
                returnOption = in.nextInt();
            }
            catch (InputMismatchException ignored) {
            }
            return returnOption;
        }
    }

