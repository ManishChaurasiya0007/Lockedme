package com.file.lock;

import com.file.lock.screens.WelcomeScreen;

public class LockedMe {

    public static void main(String[] args) {

        WelcomeScreen welcome = new WelcomeScreen();
        welcome.introWS();
        welcome.GetUserInput();

    }
}
